deploy.sh

#!/bin/bash
# Stop script on error
set -e

# Build the Docker image
docker build -t arithmetic-calculator .

# Run the Docker container
docker run -p 5000:80 arithmetic-calculator
```

```powershell