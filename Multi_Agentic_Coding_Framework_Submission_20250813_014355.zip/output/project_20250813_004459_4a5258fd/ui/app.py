app.py

import streamlit as st
from fractions import Fraction

# Function to perform arithmetic operations
def calculate(number1, operation, number2):
    if operation == '+':
        return number1 + number2
    elif operation == '-':
        return number1 - number2
    elif operation == '*':
        return number1 * number2
    elif operation == '/':
        if number2 != 0:
            return number1 / number2
        else:
            return 'Error: Division by Zero'
    elif operation == '%':
        return number1 % number2
    else:
        return 'Invalid operation'

# Layout
st.title('Arithmetic Calculator')

# User Input
num1 = st.number_input('Enter the first number', format="%f")
op = st.selectbox('Choose an operation', ['+', '-', '*', '/', '%'])
num2 = st.number_input('Enter the second number', format="%f")

# Calculation and Display
if st.button('Calculate'):
    result = calculate(num1, op, num2)
    st.write('Result:', result)
```

```python

# Error handling
def handle_error(error):
    st.error(f"An error occurred: {error}")
    st.info("Please try again or contact support if the problem persists.")

# Input validation
def validate_input(input_value, field_name):
    if not input_value or input_value.strip() == "":
        st.error(f"{field_name} cannot be empty")
        return False
    return True
