import os
import sys
from typing import Dict, Any, List

# Arithmetic Calculator

This is a simple arithmetic calculator that can perform addition, subtraction, multiplication, division, and modulus operations on integers, fractions, and decimal numbers. The calculator provides a user-friendly interface for easy input and output of calculations.

## Usage

Run the `main.py` file to start the calculator. The program will prompt you to enter the operation and numbers.

## Requirements

Python 3.8+

## License

MIT