import streamlit as st
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Page configuration
st.set_page_config(
    page_title="Generated Application",
    page_icon="🚀",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
.main-header {{
    font-size: 2.5rem;
    color: #1f77b4;
    text-align: center;
    margin-bottom: 2rem;
}}
.sidebar-header {{
    font-size: 1.5rem;
    color: #2c3e50;
    margin-bottom: 1rem;
}}
</style>
""", unsafe_allow_html=True)

def main():
    # Header
    st.markdown('<h1 class="main-header">🚀 Generated Application</h1>', unsafe_allow_html=True)
    
    # Sidebar
    with st.sidebar:
        st.markdown('<h2 class="sidebar-header">Navigation</h2>', unsafe_allow_html=True)
        page = st.selectbox(
            "Choose a page:",
            ["Home", "Features", "Settings", "About"]
        )
    
    # Main content
    if page == "Home":
        show_home_page()
    elif page == "Features":
        show_features_page()
    elif page == "Settings":
        show_settings_page()
    elif page == "About":
        show_about_page()

def show_home_page():
    st.header("🏠 Welcome")
    st.write("This is a generated application based on your requirements.")
    
    # Main functionality
    st.subheader("Main Functionality")
    
    # Example form
    with st.form("main_form"):
        user_input = st.text_input("Enter your input:")
        submit_button = st.form_submit_button("Submit")
        
        if submit_button:
            if user_input:
                st.success(f"Processed: {user_input}")
            else:
                st.error("Please enter some input.")

def show_features_page():
    st.header("✨ Features")
    st.write("This page showcases the main features of the application.")
    
    # Feature cards
    col1, col2 = st.columns(2)
    
    with col1:
        st.info("Feature 1")
        st.write("Description of feature 1")
    
    with col2:
        st.info("Feature 2")
        st.write("Description of feature 2")

def show_settings_page():
    st.header("⚙️ Settings")
    st.write("Configure your application settings.")
    
    # Settings form
    with st.form("settings_form"):
        st.subheader("Application Settings")
        
        debug_mode = st.checkbox("Enable Debug Mode")
        log_level = st.selectbox("Log Level", ["INFO", "DEBUG", "WARNING", "ERROR"])
        
        if st.form_submit_button("Save Settings"):
            st.success("Settings saved successfully!")

def show_about_page():
    st.header("ℹ️ About")
    st.write("Information about the application and its development.")
    
    st.subheader("Project Information")
    st.write("- Generated using Multi-Agentic Coding Framework")
    st.write("- Built with Streamlit")
    st.write("- Python-based application")

if __name__ == "__main__":
    main()


# Error handling
def handle_error(error):
    st.error(f"An error occurred: {error}")
    st.info("Please try again or contact support if the problem persists.")

# Input validation
def validate_input(input_value, field_name):
    if not input_value or input_value.strip() == "":
        st.error(f"{field_name} cannot be empty")
        return False
    return True
