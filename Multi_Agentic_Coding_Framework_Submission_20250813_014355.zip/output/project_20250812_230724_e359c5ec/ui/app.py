app.py
import streamlit as st
from pages import page1, page2 # import your pages here

PAGES = {
    "Page 1": page1,
    "Page 2": page2,
    # add more pages here
}

def main():
    st.sidebar.title('Navigation')
    selection = st.sidebar.radio("Go to", list(PAGES.keys()))
    page = PAGES[selection]
    page.app()

if __name__ == "__main__":
    main()
```
2. **UI Components** (`components/`):
You can create custom components using Python functions and then import them into your main app or pages.

3. **Pages** (`pages/`):
Every page is a separate Python file with a function named `app()`. Here's an example of a page:
```python

# Error handling
def handle_error(error):
    st.error(f"An error occurred: {error}")
    st.info("Please try again or contact support if the problem persists.")

# Input validation
def validate_input(input_value, field_name):
    if not input_value or input_value.strip() == "":
        st.error(f"{field_name} cannot be empty")
        return False
    return True
