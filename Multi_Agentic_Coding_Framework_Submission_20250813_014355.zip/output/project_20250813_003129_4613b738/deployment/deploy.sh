deploy.sh
#!/bin/bash
docker build -t calculator-app .
docker run -p 8080:8080 calculator-app
```

```powershell