#!/usr/bin/env python3
"""
Basic test script to verify framework functionality without API calls.
"""

import os
import sys
from typing import Dict, Any

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def test_imports():
    """Test that all modules can be imported."""
    print("Testing imports...")
    
    try:
        from core.config import config
        print("✓ Core config imported successfully")
    except Exception as e:
        print(f"✗ Core config import failed: {e}")
        return False
    
    try:
        from core.utils import setup_logging
        print("✓ Core utils imported successfully")
    except Exception as e:
        print(f"✗ Core utils import failed: {e}")
        return False
    
    try:
        from agents.requirement_agent import RequirementAnalysisAgent
        print("✓ Requirement agent imported successfully")
    except Exception as e:
        print(f"✗ Requirement agent import failed: {e}")
        return False
    
    try:
        from agents.coding_agent import CodingAgent
        print("✓ Coding agent imported successfully")
    except Exception as e:
        print(f"✗ Coding agent import failed: {e}")
        return False
    
    try:
        from agents.review_agent import CodeReviewAgent
        print("✓ Review agent imported successfully")
    except Exception as e:
        print(f"✗ Review agent import failed: {e}")
        return False
    
    try:
        from agents.documentation_agent import DocumentationAgent
        print("✓ Documentation agent imported successfully")
    except Exception as e:
        print(f"✗ Documentation agent import failed: {e}")
        return False
    
    try:
        from agents.test_agent import TestCaseGenerationAgent
        print("✓ Test agent imported successfully")
    except Exception as e:
        print(f"✗ Test agent import failed: {e}")
        return False
    
    try:
        from agents.deployment_agent import DeploymentConfigurationAgent
        print("✓ Deployment agent imported successfully")
    except Exception as e:
        print(f"✗ Deployment agent import failed: {e}")
        return False
    
    try:
        from agents.ui_agent import StreamlitUIAgent
        print("✓ UI agent imported successfully")
    except Exception as e:
        print(f"✗ UI agent import failed: {e}")
        return False
    
    return True

def test_config():
    """Test configuration loading."""
    print("\nTesting configuration...")
    
    try:
        from core.config import config
        print(f"✓ Config loaded successfully")
        print(f"  - Model: {config.model_name}")
        print(f"  - Temperature: {config.temperature}")
        print(f"  - Max iterations: {config.max_iterations}")
        print(f"  - Output dir: {config.output_dir}")
        return True
    except Exception as e:
        print(f"✗ Config test failed: {e}")
        return False

def test_agent_initialization():
    """Test agent initialization (without API calls)."""
    print("\nTesting agent initialization...")
    
    try:
        from agents.requirement_agent import RequirementAnalysisAgent
        agent = RequirementAnalysisAgent()
        print("✓ Requirement agent initialized successfully")
        return True
    except Exception as e:
        print(f"✗ Agent initialization failed: {e}")
        return False

def test_utils():
    """Test utility functions."""
    print("\nTesting utility functions...")
    
    try:
        from core.utils import setup_logging, save_json, load_json
        logger = setup_logging()
        print("✓ Logging setup successful")
        
        # Test JSON operations
        test_data = {"test": "data", "number": 42}
        test_file = "test_output.json"
        
        filepath = save_json(test_data, test_file, "./output")
        print("✓ JSON save successful")
        
        loaded_data = load_json(filepath)
        print("✓ JSON load successful")
        
        # Cleanup
        if os.path.exists(os.path.join("./output", test_file)):
            os.remove(os.path.join("./output", test_file))
            print("✓ Test file cleaned up")
        
        return True
    except Exception as e:
        print(f"✗ Utils test failed: {e}")
        return False

def main():
    """Run all tests."""
    print("=== Multi-Agentic Framework Basic Tests ===\n")
    
    tests = [
        test_imports,
        test_config,
        test_agent_initialization,
        test_utils
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n=== Test Results ===")
    print(f"Passed: {passed}/{total}")
    
    if passed == total:
        print("🎉 All tests passed! Framework is ready for use.")
        print("\nNext steps:")
        print("1. Create a .env file with your OpenAI API key")
        print("2. Run: streamlit run app.py")
    else:
        print("❌ Some tests failed. Please check the errors above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1) 