"""
Test Case Generation Agent for the Multi-Agentic Coding Framework.
Creates unit tests and integration tests for the developed code.
"""

import autogen
import re
from typing import Dict, Any, List
from core.config import get_agent_config, config
from core.utils import save_to_file, setup_logging, load_from_file, validate_python_code

logger = setup_logging()

class TestCaseGenerationAgent:
    """Agent responsible for generating test cases."""
    
    def __init__(self):
        self.agent_config = get_agent_config("test_agent")
        self.llm_config = config.get_llm_config()
        
        # Create the agent
        self.agent = autogen.AssistantAgent(
            name=self.agent_config["name"],
            system_message=self.agent_config["system_message"],
            llm_config=self.llm_config
        )
        
        # Create user proxy for interaction
        self.user_proxy = autogen.UserProxyAgent(
            name="user_proxy",
            human_input_mode="NEVER",
            max_consecutive_auto_reply=10,
            is_termination_msg=lambda x: "TERMINATE" in x.get("content", ""),
            code_execution_config={"work_dir": "workspace", "use_docker": False},
            llm_config=self.llm_config
        )
    
    def generate_tests(self, generated_code: Dict[str, Any], requirements: Dict[str, Any], project_id: str) -> Dict[str, Any]:
        """
        Generate comprehensive test cases for the developed code.
        
        Args:
            generated_code: Output from CodingAgent containing generated files
            requirements: Original requirements for context
            project_id: Unique project identifier
            
        Returns:
            Dict containing generated test files and test results
        """
        logger.info("Starting test case generation")
        
        # Load the actual code content
        code_files = {}
        for filename, filepath in generated_code.get("generated_files", {}).items():
            try:
                code_files[filename] = load_from_file(filepath)
            except Exception as e:
                logger.warning(f"Could not load file {filename}: {e}")
                code_files[filename] = f"# Error loading file: {e}"
        
        # Create the test generation prompt
        test_prompt = f"""
Please generate comprehensive test cases for the following Python project:

PROJECT REQUIREMENTS:
{self._format_requirements_for_testing(requirements)}

GENERATED CODE FILES:
{self._format_code_for_testing(code_files)}

Please generate the following test files:

1. **Unit Tests** (`test_main.py`, `test_config.py`, etc.):
   - Test individual functions and methods
   - Test edge cases and error conditions
   - Test input validation
   - Test return values and side effects

2. **Integration Tests** (`test_integration.py`):
   - Test component interactions
   - Test end-to-end functionality
   - Test data flow between components

3. **Test Configuration** (`conftest.py`):
   - Test fixtures and setup
   - Test data and mock objects
   - Test configuration

4. **Test Requirements** (`requirements-test.txt`):
   - Testing dependencies (pytest, pytest-cov, etc.)

For each test file, provide:
- Comprehensive test coverage
- Clear test names and descriptions
- Proper setup and teardown
- Mock objects where appropriate
- Edge case testing
- Error condition testing

Test Requirements:
- Use pytest framework
- Include proper assertions
- Test both success and failure cases
- Include performance tests where appropriate
- Ensure good test coverage

Please provide each test file in the following format:

```python
# filename: test_main.py
[complete test code here]
```

```python
# filename: test_integration.py
[complete test code here]
```

And so on for each file.

IMPORTANT: End your response with the word "TERMINATE" to indicate completion.
"""
        
        try:
            # Start the conversation
            chat_result = self.user_proxy.initiate_chat(
                self.agent,
                message=test_prompt
            )
            
            # Extract the LLM response using utility function
            from core.utils import extract_llm_response
            last_message = extract_llm_response(chat_result)
            
            # Parse and organize the generated tests
            generated_tests = self._parse_generated_tests(last_message)
            
            # Validate and enhance the tests
            validated_tests = self._validate_and_enhance_tests(generated_tests, code_files)
            
            # Save the generated tests
            saved_tests = self._save_generated_tests(validated_tests, project_id)
            
            # Run the tests to check if they work
            test_results = self._run_generated_tests(saved_tests, project_id)
            
            result = {
                "project_id": project_id,
                "generated_tests": saved_tests,
                "test_results": test_results,
                "total_tests": len(saved_tests),
                "test_coverage": self._calculate_test_coverage(validated_tests, code_files)
            }
            
            logger.info(f"Test generation completed. Generated {len(saved_tests)} test files.")
            return result
            
        except Exception as e:
            logger.error(f"Error in test generation: {e}")
            # Generate fallback tests
            fallback_tests = self._generate_fallback_tests(requirements, code_files, project_id)
            return {
                "project_id": project_id,
                "generated_tests": fallback_tests,
                "test_results": {"status": "error", "message": str(e)},
                "total_tests": len(fallback_tests),
                "test_coverage": {"coverage": 0, "message": "Fallback tests generated"},
                "error": str(e)
            }
    
    def _format_requirements_for_testing(self, requirements: Dict[str, Any]) -> str:
        """Format requirements for testing context."""
        formatted = f"""
Project: {requirements.get('project_name', 'N/A')}
Description: {requirements.get('description', 'N/A')}

Functional Requirements to Test:
"""
        
        for req in requirements.get('functional_requirements', []):
            formatted += f"""
- {req.get('id', 'N/A')}: {req.get('title', 'N/A')}
  Description: {req.get('description', 'N/A')}
  Acceptance Criteria: {', '.join(req.get('acceptance_criteria', []))}
  Test Focus: Verify that {req.get('description', 'N/A')}
"""
        
        formatted += f"""
Non-Functional Requirements to Test:
"""
        
        for req in requirements.get('non_functional_requirements', []):
            formatted += f"""
- {req.get('id', 'N/A')}: {req.get('title', 'N/A')}
  Category: {req.get('category', 'N/A')}
  Description: {req.get('description', 'N/A')}
  Test Focus: Verify {req.get('category', 'N/A')} requirements
"""
        
        return formatted
    
    def _format_code_for_testing(self, code_files: Dict[str, str]) -> str:
        """Format code files for testing generation."""
        formatted = ""
        
        for filename, content in code_files.items():
            formatted += f"""
=== FILE: {filename} ===
{content}
=== END FILE: {filename} ===

"""
        
        return formatted
    
    def _parse_generated_tests(self, response: str) -> Dict[str, str]:
        """Parse the generated test response and extract individual files."""
        import re
        
        files = {}
        
        # Look for filename patterns in the response
        filename_pattern = r'# filename: ([^\n]+)'
        filename_matches = re.findall(filename_pattern, response)
        
        # Split the response by filename markers
        sections = re.split(r'# filename:', response)
        
        if len(sections) > 1:
            for i, section in enumerate(sections[1:], 1):
                if i <= len(filename_matches):
                    filename = filename_matches[i-1].strip()
                    # Extract content after the filename
                    content = section.strip()
                    if content:
                        files[filename] = content
        else:
            # Fallback: create basic test structure
            files = self._create_basic_test_structure(response)
        
        return files
    
    def _create_basic_test_structure(self, response: str) -> Dict[str, str]:
        """Create basic test structure when parsing fails."""
        return {
            "test_main.py": f"""import pytest
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def test_main_function_exists():
    \"\"\"Test that the main function exists and can be called.\"\"\"
    try:
        from main import main
        assert callable(main)
    except ImportError:
        pytest.skip("main module not available")

def test_main_function_runs():
    \"\"\"Test that the main function runs without errors.\"\"\"
    try:
        from main import main
        # This should not raise an exception
        main()
    except Exception as e:
        pytest.fail(f"main function failed: {{e}}")

def test_basic_functionality():
    \"\"\"Test basic functionality of the application.\"\"\"
    # Add specific tests based on requirements
    assert True  # Placeholder test
""",
            "test_config.py": f"""import pytest
import os

def test_config_import():
    \"\"\"Test that config module can be imported.\"\"\"
    try:
        from config import Config
        assert True
    except ImportError:
        pytest.skip("config module not available")

def test_config_initialization():
    \"\"\"Test that Config class can be instantiated.\"\"\"
    try:
        from config import Config
        config = Config()
        assert config is not None
    except Exception as e:
        pytest.fail(f"Config initialization failed: {{e}}")

def test_config_attributes():
    \"\"\"Test that Config has expected attributes.\"\"\"
    try:
        from config import Config
        config = Config()
        # Test basic attributes
        assert hasattr(config, 'app_name')
        assert hasattr(config, 'version')
    except Exception as e:
        pytest.fail(f"Config attributes test failed: {{e}}")
""",
            "conftest.py": f"""import pytest
import os
import sys

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

@pytest.fixture
def sample_data():
    \"\"\"Provide sample data for tests.\"\"\"
    return {{
        "test_string": "test_value",
        "test_number": 42,
        "test_list": [1, 2, 3, 4, 5]
    }}

@pytest.fixture
def temp_file(tmp_path):
    \"\"\"Provide a temporary file for testing.\"\"\"
    temp_file = tmp_path / "test_file.txt"
    temp_file.write_text("test content")
    return temp_file

@pytest.fixture
def mock_environment(monkeypatch):
    \"\"\"Mock environment variables for testing.\"\"\"
    monkeypatch.setenv("TEST_ENV", "test_value")
    monkeypatch.setenv("DEBUG", "True")
    return {{
        "TEST_ENV": "test_value",
        "DEBUG": "True"
    }}
""",
            "requirements-test.txt": f"""# Testing dependencies
pytest>=7.0.0
pytest-cov>=4.0.0
pytest-mock>=3.10.0
pytest-asyncio>=0.21.0
"""
        }
    
    def _validate_and_enhance_tests(self, tests: Dict[str, str], code_files: Dict[str, str]) -> Dict[str, str]:
        """Validate and enhance the generated tests."""
        enhanced_tests = {}
        
        for filename, content in tests.items():
            # Validate the test code
            validation = validate_python_code(content)
            
            if validation["valid"]:
                # Enhance the tests with additional coverage
                enhanced_content = self._enhance_test_coverage(content, code_files)
                enhanced_tests[filename] = enhanced_content
            else:
                # Fix common test issues
                fixed_content = self._fix_common_test_issues(content)
                enhanced_tests[filename] = fixed_content
        
        return enhanced_tests
    
    def _enhance_test_coverage(self, test_content: str, code_files: Dict[str, str]) -> str:
        """Enhance test coverage with additional test cases."""
        enhanced = test_content
        
        # Add basic test coverage if not present
        if "def test_" not in enhanced:
            enhanced += """

# Additional test cases for better coverage
def test_basic_functionality():
    \"\"\"Test basic functionality.\"\"\"
    assert True

def test_error_handling():
    \"\"\"Test error handling.\"\"\"
    try:
        # Test error conditions
        pass
    except Exception:
        assert True  # Expected error

def test_edge_cases():
    \"\"\"Test edge cases.\"\"\"
    # Test with empty inputs
    # Test with boundary values
    assert True
"""
        
        return enhanced
    
    def _fix_common_test_issues(self, test_content: str) -> str:
        """Fix common issues in test code."""
        # Add basic imports if missing
        if "import pytest" not in test_content:
            test_content = "import pytest\nimport sys\nimport os\n\n" + test_content
        
        # Add basic test structure if missing
        if "def test_" not in test_content:
            test_content += """

def test_basic():
    \"\"\"Basic test to ensure tests can run.\"\"\"
    assert True
"""
        
        return test_content
    
    def _save_generated_tests(self, tests: Dict[str, str], project_id: str) -> Dict[str, str]:
        """Save generated tests to files and return content."""
        saved_tests = {}
        
        for filename, content in tests.items():
            # Create project-specific test directory
            project_dir = f"{config.output_dir}/{project_id}/tests"
            filepath = save_to_file(content, filename, project_dir)
            # Return the content, not the filepath, for frontend display
            saved_tests[filename] = content
        
        return saved_tests
    
    def _run_generated_tests(self, saved_tests: Dict[str, str], project_id: str) -> Dict[str, Any]:
        """Run the generated tests to check if they work."""
        try:
            import subprocess
            import sys
            
            # Change to the project directory
            project_dir = f"{config.output_dir}/{project_id}"
            
            # Run pytest
            result = subprocess.run(
                [sys.executable, "-m", "pytest", "tests/", "-v", "--tb=short"],
                cwd=project_dir,
                capture_output=True,
                text=True,
                timeout=30
            )
            
            return {
                "status": "completed",
                "return_code": result.returncode,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "success": result.returncode == 0
            }
            
        except Exception as e:
            return {
                "status": "error",
                "message": str(e),
                "success": False
            }
    
    def _calculate_test_coverage(self, tests: Dict[str, str], code_files: Dict[str, str]) -> Dict[str, Any]:
        """Calculate test coverage metrics."""
        total_test_functions = 0
        total_code_functions = 0
        
        # Count test functions
        for test_content in tests.values():
            import re
            test_functions = len(re.findall(r'def test_', test_content))
            total_test_functions += test_functions
        
        # Count code functions
        for code_content in code_files.values():
            if code_content.endswith('.py'):
                import re
                code_functions = len(re.findall(r'def ', code_content))
                total_code_functions += code_functions
        
        coverage = (total_test_functions / max(total_code_functions, 1)) * 100
        
        return {
            "coverage_percentage": min(coverage, 100),
            "total_test_functions": total_test_functions,
            "total_code_functions": total_code_functions,
            "coverage_level": "high" if coverage >= 80 else "medium" if coverage >= 50 else "low"
        }
    
    def _generate_fallback_tests(self, requirements: Dict[str, Any], code_files: Dict[str, str], project_id: str) -> Dict[str, str]:
        """Generate basic fallback tests when the main generation fails."""
        project_name = requirements.get('project_name', 'GeneratedProject').replace(' ', '_')
        
        test_main = f"""import pytest
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class Test{project_name}:
    \"\"\"Test suite for {project_name}.\"\"\"
    
    def test_project_import(self):
        \"\"\"Test that the main project can be imported.\"\"\"
        try:
            import main
            assert True
        except ImportError as e:
            pytest.skip(f"Could not import main module: {{e}}")
    
    def test_main_function_exists(self):
        \"\"\"Test that the main function exists.\"\"\"
        try:
            from main import main
            assert callable(main)
        except ImportError:
            pytest.skip("main module not available")
    
    def test_config_import(self):
        \"\"\"Test that the config module can be imported.\"\"\"
        try:
            import config
            assert True
        except ImportError:
            pytest.skip("config module not available")
    
    def test_basic_functionality(self):
        \"\"\"Test basic functionality based on requirements.\"\"\"
        # Test based on functional requirements
        for req in {requirements.get('functional_requirements', [])}:
            assert req.get('id') is not None
            assert req.get('title') is not None
            assert req.get('description') is not None
    
    def test_error_handling(self):
        \"\"\"Test error handling capabilities.\"\"\"
        # Test that the application handles errors gracefully
        assert True  # Placeholder for actual error handling tests
    
    def test_edge_cases(self):
        \"\"\"Test edge cases and boundary conditions.\"\"\"
        # Test with empty inputs, null values, etc.
        assert True  # Placeholder for edge case tests
"""
        
        test_integration = f"""import pytest
import sys
import os

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

class TestIntegration:
    \"\"\"Integration tests for {project_name}.\"\"\"
    
    def test_end_to_end_workflow(self):
        \"\"\"Test the complete workflow from start to finish.\"\"\"
        try:
            from main import main
            # Test that the main function can be called
            main()
            assert True
        except Exception as e:
            pytest.fail(f"End-to-end test failed: {{e}}")
    
    def test_component_interaction(self):
        \"\"\"Test interaction between different components.\"\"\"
        try:
            from config import Config
            from main import main
            
            # Test that config and main work together
            config = Config()
            assert config is not None
            
            # Test that main can use config
            main()
            assert True
        except Exception as e:
            pytest.fail(f"Component interaction test failed: {{e}}")
    
    def test_data_flow(self):
        \"\"\"Test data flow between components.\"\"\"
        # Test how data flows through the application
        assert True  # Placeholder for data flow tests
    
    def test_performance(self):
        \"\"\"Test performance characteristics.\"\"\"
        import time
        
        start_time = time.time()
        try:
            from main import main
            main()
            end_time = time.time()
            
            # Ensure the application completes within reasonable time
            assert (end_time - start_time) < 10  # 10 seconds timeout
        except Exception as e:
            pytest.fail(f"Performance test failed: {{e}}")
"""
        
        conftest = f"""import pytest
import os
import sys

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

@pytest.fixture(scope="session")
def project_config():
    \"\"\"Provide project configuration for tests.\"\"\"
    return {{
        "project_name": "{project_name}",
        "requirements": {requirements},
        "test_mode": True
    }}

@pytest.fixture
def sample_data():
    \"\"\"Provide sample data for tests.\"\"\"
    return {{
        "test_string": "test_value",
        "test_number": 42,
        "test_list": [1, 2, 3, 4, 5],
        "test_dict": {{"key": "value"}}
    }}

@pytest.fixture
def temp_file(tmp_path):
    \"\"\"Provide a temporary file for testing.\"\"\"
    temp_file = tmp_path / "test_file.txt"
    temp_file.write_text("test content")
    return temp_file

@pytest.fixture
def mock_environment(monkeypatch):
    \"\"\"Mock environment variables for testing.\"\"\"
    monkeypatch.setenv("TEST_ENV", "test_value")
    monkeypatch.setenv("DEBUG", "True")
    monkeypatch.setenv("PROJECT_NAME", "{project_name}")
    return {{
        "TEST_ENV": "test_value",
        "DEBUG": "True",
        "PROJECT_NAME": "{project_name}"
    }}

@pytest.fixture
def cleanup_files():
    \"\"\"Cleanup fixture for test files.\"\"\"
    yield
    # Cleanup code here if needed
"""
        
        requirements_test = f"""# Testing dependencies for {project_name}
pytest>=7.0.0
pytest-cov>=4.0.0
pytest-mock>=3.10.0
pytest-asyncio>=0.21.0
pytest-html>=3.1.0
pytest-xdist>=3.0.0
"""
        
        return {
            "test_main.py": test_main,
            "test_integration.py": test_integration,
            "conftest.py": conftest,
            "requirements-test.txt": requirements_test
        } 