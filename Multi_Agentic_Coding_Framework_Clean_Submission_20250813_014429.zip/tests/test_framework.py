"""
Test suite for the Multi-Agentic Coding Framework.
Tests the core functionality and agent interactions.
"""

import pytest
import sys
import os
from unittest.mock import Mock, patch

# Add the project root to the path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from core.config import config, get_agent_config
from core.utils import (
    setup_logging, save_to_file, load_from_file, generate_project_id,
    create_project_structure, validate_python_code
)
from core.coordinator import MultiAgentCoordinator

class TestConfiguration:
    """Test configuration module."""
    
    def test_config_initialization(self):
        """Test that configuration initializes correctly."""
        assert config is not None
        assert hasattr(config, 'openai_api_key')
        assert hasattr(config, 'model_name')
        assert hasattr(config, 'max_iterations')
        assert hasattr(config, 'temperature')
    
    def test_get_agent_config(self):
        """Test getting agent configurations."""
        agent_config = get_agent_config("requirement_agent")
        assert agent_config is not None
        assert "name" in agent_config
        assert "system_message" in agent_config
        assert agent_config["name"] == "Requirement Analysis Agent"
    
    def test_get_unknown_agent_config(self):
        """Test getting configuration for unknown agent."""
        with pytest.raises(ValueError):
            get_agent_config("unknown_agent")

class TestUtils:
    """Test utility functions."""
    
    def test_setup_logging(self):
        """Test logging setup."""
        logger = setup_logging("INFO")
        assert logger is not None
        assert logger.level == 20  # INFO level
    
    def test_save_and_load_file(self, tmp_path):
        """Test file save and load operations."""
        test_content = "Test content for file operations"
        test_file = tmp_path / "test.txt"
        
        # Test save
        filepath = save_to_file(test_content, "test.txt", str(tmp_path))
        assert os.path.exists(filepath)
        
        # Test load
        loaded_content = load_from_file(filepath)
        assert loaded_content == test_content
    
    def test_generate_project_id(self):
        """Test project ID generation."""
        requirement = "Test requirement"
        project_id = generate_project_id(requirement)
        
        assert project_id is not None
        assert project_id.startswith("project_")
        assert len(project_id) > 20  # Should be reasonably long
    
    def test_create_project_structure(self, tmp_path):
        """Test project structure creation."""
        project_id = "test_project"
        directories = create_project_structure(project_id, str(tmp_path))
        
        assert "root" in directories
        assert "src" in directories
        assert "tests" in directories
        assert "docs" in directories
        assert "deployment" in directories
        assert "ui" in directories
        
        # Check that directories were created
        for dir_path in directories.values():
            assert os.path.exists(dir_path)
    
    def test_validate_python_code(self):
        """Test Python code validation."""
        valid_code = """
def test_function():
    return "Hello, World!"
"""
        invalid_code = """
def test_function(
    return "Hello, World!"
"""
        
        # Test valid code
        result = validate_python_code(valid_code)
        assert result["valid"] is True
        assert "test_function" in result["functions"]
        
        # Test invalid code
        result = validate_python_code(invalid_code)
        assert result["valid"] is False
        assert len(result["errors"]) > 0

class TestCoordinator:
    """Test the main coordinator."""
    
    def test_coordinator_initialization(self):
        """Test coordinator initialization."""
        coordinator = MultiAgentCoordinator()
        assert coordinator is not None
        assert hasattr(coordinator, 'requirement_agent')
        assert hasattr(coordinator, 'coding_agent')
        assert hasattr(coordinator, 'review_agent')
        assert hasattr(coordinator, 'documentation_agent')
        assert hasattr(coordinator, 'test_agent')
        assert hasattr(coordinator, 'deployment_agent')
        assert hasattr(coordinator, 'ui_agent')
    
    def test_list_projects_empty(self):
        """Test listing projects when none exist."""
        coordinator = MultiAgentCoordinator()
        projects = coordinator.list_projects()
        assert isinstance(projects, list)
    
    @patch('core.coordinator.config')
    def test_process_requirement_mock(self, mock_config):
        """Test requirement processing with mocked agents."""
        mock_config.output_dir = "/tmp/test_output"
        
        coordinator = MultiAgentCoordinator()
        
        # Mock the agents to avoid actual API calls
        coordinator.requirement_agent.analyze_requirement = Mock(return_value={
            "project_name": "Test Project",
            "description": "Test description",
            "functional_requirements": []
        })
        
        coordinator.coding_agent.generate_code = Mock(return_value={
            "project_id": "test_project",
            "generated_files": {},
            "total_files": 0
        })
        
        coordinator.review_agent.review_code = Mock(return_value={
            "overall_score": 85,
            "passes_review": True,
            "requires_revision": False
        })
        
        # Test processing
        requirement = "Create a simple calculator application"
        results = coordinator.process_requirement(requirement)
        
        assert results is not None
        assert "project_id" in results
        assert "agents" in results
        assert "final_status" in results

class TestAgents:
    """Test individual agents."""
    
    @patch('core.config.config')
    def test_requirement_agent_initialization(self, mock_config):
        """Test requirement agent initialization."""
        mock_config.get_llm_config.return_value = {
            "config_list": [{"model": "gpt-4", "api_key": "test"}],
            "temperature": 0.7
        }
        
        from agents.requirement_agent import RequirementAnalysisAgent
        agent = RequirementAnalysisAgent()
        assert agent is not None
        assert hasattr(agent, 'agent')
        assert hasattr(agent, 'user_proxy')
    
    @patch('core.config.config')
    def test_coding_agent_initialization(self, mock_config):
        """Test coding agent initialization."""
        mock_config.get_llm_config.return_value = {
            "config_list": [{"model": "gpt-4", "api_key": "test"}],
            "temperature": 0.7
        }
        
        from agents.coding_agent import CodingAgent
        agent = CodingAgent()
        assert agent is not None
        assert hasattr(agent, 'agent')
        assert hasattr(agent, 'user_proxy')

class TestIntegration:
    """Integration tests."""
    
    def test_end_to_end_workflow_mock(self):
        """Test the complete workflow with mocked components."""
        # This test would simulate the complete workflow
        # without making actual API calls
        pass
    
    def test_error_handling(self):
        """Test error handling in the framework."""
        # Test various error scenarios
        pass

# Fixtures for testing
@pytest.fixture
def sample_requirement():
    """Sample requirement for testing."""
    return "Create a simple web application that displays a hello world message"

@pytest.fixture
def sample_requirements():
    """Sample structured requirements for testing."""
    return {
        "project_name": "Test Project",
        "description": "A test project for validation",
        "functional_requirements": [
            {
                "id": "FR001",
                "title": "Display Message",
                "description": "Display a hello world message",
                "priority": "high",
                "acceptance_criteria": ["Message is displayed correctly"]
            }
        ],
        "non_functional_requirements": [],
        "technical_constraints": [],
        "assumptions": [],
        "dependencies": [],
        "estimated_complexity": "low",
        "suggested_architecture": "Simple web application",
        "key_components": ["Web interface"]
    }

@pytest.fixture
def sample_code():
    """Sample generated code for testing."""
    return {
        "project_id": "test_project",
        "generated_files": {
            "main.py": "print('Hello, World!')",
            "requirements.txt": "streamlit>=1.0.0"
        },
        "total_files": 2,
        "main_file": "main.py"
    } 